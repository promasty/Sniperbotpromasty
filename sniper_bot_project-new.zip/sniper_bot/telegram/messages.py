# Placeholder for telegram/messages.py
